https://youtu.be/9oAS1Co7lKQ - Demo Video

The best way to display the app as it's meant to be seen by the user is through this link https://creator.ionic.io/share/ca3f90ec1cea
If you wish to compile it through the IDE, it's best to use these commands (https://docs.usecreator.com/docs/zip-export-an-ionic-project) specific to an
ionic application. Specify port with using "$ ionic serve --port 8080" Once compiled, it's best to convert to an iPhone7 or iPhone6 view
(https://developers.google.com/web/tools/chrome-devtools/device-mode/).

The first page, although not especially stylish (further work to be done), explains the purpose of the app to come. It's a business idea I've been developing
for a long time and want to take a shot at. The CS50 Project is meant to lay the foundation for the app's UI to be displayed in pitches for investors and
accelerators. It has two of the main features, which are 1) a list of guides with simple profiles in them; 2) a map in which the traveler can see themselves
and search for guides nearby.

If you shift the toggle on, you will see two more stars appear in preset coordinates. If you choose the streetview option, you can see the stars in a
more exact point on the street. Everything is pretty self-explanatory, I believe.

Now, the map will eventually have options to select guides within a certain radius; see their profile picture, name and some other basic info upon clicking
the marker; a link on the marker's popup to visit the extended profile of the guide. I will also introduce a database to track the logins and store the
accounts following the signup. Furthermore, the buttons that are currently just there for show (like the ones in Login and Register, as well as the options
to message guides, see their suggestions for the city and prefered tour itineraries, requests to meet up) will be made functional.
I'll also introduce functionality to measure the distance between a selected guide and a traveler and suggest the ideal meeting point between them
(a famous sight/popular cafe in the middle). + comments and evaluations for the guides, a payment transfer system based on the time of the tour, an ability
to connect to a tour guide, the guide's side of the app, a website to accompany the service, css-html-design work and much much more. However, although
there are tons of work to still do, on which I'll be working through the break and the next semester, this looks like a very promising start.

