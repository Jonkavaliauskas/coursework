angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('odyssey', {
    url: '/page1',
    templateUrl: 'templates/odyssey.html',
    controller: 'odysseyCtrl'
  })

  .state('odyssey2', {
    url: '/page2',
    templateUrl: 'templates/odyssey2.html',
    controller: 'odyssey2Ctrl'
  })

  .state('signup', {
    url: '/page3',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('login', {
    url: '/page4',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('guidesAvailable', {
    url: '/page5',
    templateUrl: 'templates/guidesAvailable.html',
    controller: 'guidesAvailableCtrl'
  })

  .state('odyssey3', {
    url: '/page7',
    templateUrl: 'templates/odyssey3.html',
    controller: 'odyssey3Ctrl'
  })

  .state('odyssey4', {
    url: '/page17',
    templateUrl: 'templates/odyssey4.html',
    controller: 'odyssey4Ctrl'
  })

  .state('odyssey5', {
    url: '/page18',
    templateUrl: 'templates/odyssey5.html',
    controller: 'odyssey5Ctrl'
  })

  .state('odyssey6', {
    url: '/page11',
    templateUrl: 'templates/odyssey6.html',
    controller: 'odyssey6Ctrl'
  })

  .state('odyssey7', {
    url: '/page13',
    templateUrl: 'templates/odyssey7.html',
    controller: 'odyssey7Ctrl'
  })

  .state('odyssey8', {
    url: '/page9',
    templateUrl: 'templates/odyssey8.html',
    controller: 'odyssey8Ctrl'
  })

  .state('odyssey9', {
    url: '/page12',
    templateUrl: 'templates/odyssey9.html',
    controller: 'odyssey9Ctrl'
  })

  .state('odyssey10', {
    url: '/page15',
    templateUrl: 'templates/odyssey10.html',
    controller: 'odyssey10Ctrl'
  })

  .state('odyssey11', {
    url: '/page8',
    templateUrl: 'templates/odyssey11.html',
    controller: 'odyssey11Ctrl'
  })

  .state('odyssey12', {
    url: '/page16',
    templateUrl: 'templates/odyssey12.html',
    controller: 'odyssey12Ctrl'
  })

$urlRouterProvider.otherwise('/page1')


});