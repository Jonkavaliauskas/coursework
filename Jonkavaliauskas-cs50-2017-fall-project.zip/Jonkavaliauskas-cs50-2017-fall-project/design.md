The major challenge I faced in implementing my project was learning Ionic Framework and AngularJS from scratch. I knew I wanted to build Odyssey and after
sharing my idea with my best friend (currently at Cambridge University), he suggested that I use Ionic, a framework he had been using this past summer while
working for a software company. He noted that it's a very specific professional tool, not used by many out there, but forgot to mention that he'll be out
skiing the two weeks that I was working on my project most intensely (all of this week and most of last week). Hence, having already done some work learning
Ionic, I was left in the precarious position of not wanting to go back and start over, yet knowing that continuing with Ionic meant that I would have to do
it with little or no help. It was hard understanding whether Ionic was truly built on top of Angular or not and how exactly the integration of the two works.
In my opinion, the documentation offered by Ionic is quite vague and unhelpful (at least for somebody coding at my level), and there are relatively few
guides and tutorials online to refer to. Furthermore, there are many different versions of the framework, which makes the guides and the documentation even
more confusing than they have to be. In addition, by default, Ionic V1 is chosen for the user (rather than V2 or up), whereas most guides out there are for
later versions. Finally, most people I know have only used AngularJS 2, whereas Ionic V1 uses AngularJS 1. The two are very different and my Angular friends
were also of little help in that regard. Hence, I was left reading the documentation and watching thousands of videos explaining both. I don't know whether
I fully understood everything, and a lot of the code was written by looking up similar examples online (GitHub and Stackexchange mostly) and testing them
through trial and error.

First of all, by no means are all the files here written by me. In fact, most of it is provided by the framework (before the user has to get down to
hardcoding it all, a lot can be done through simple drag and drop). I have, however, written most of the HTML files (the guide profiles, a lot of them copy
and pasted from the original profile I made for Laura), except for login and signup. For example, let's take "odyssey3.html". Most of what's after line
21 is written or heavily tweaked by me. The bar for the number of hours of tours given and the star rating is added, the remaining icons are edited
(although little is done with the buttons in the very end). This HTML code seems pretty straight forward and is what I've assembled together from various
guides and documentation on HTML online.

The heavy coding part really comes in when working on the map. First of all, I center the map and set out the coordinates as a list (one in the center
to represent the traveler and two around it to represent the guides) within googlemaps.init.js (lines 38-70). I then call upon these in odyssey2.html,
a file written by me. I iterate through this list using the AngularJS directive ng-repeat, showing each marker in the desired coordinates. Furthermore,
within odyssey2.html, I introduce "settings.toggleButton.on || (m.id ==1)" - the ToggleButton functionality defined in controllers.js (where the first
30 lines are written by me). The markers then show up with the use of AngularJS directive "ng-if" if their id is 1 (central marker) OR the Toggle is turned
on. A similar approach has not yet worked (I suspect, because I'm using the wrong directive and have trouble working through the routing within the HTML
file) for the click="settings.map.markClicked(m.id)" function (so that when the marker is clicked, we get a popup and a link to the guide's profile), but
it will, soon. I left the console.log in controllers.js as it's been a useful tool in debugging my code in general, and shows that we can already identify
a click on a marker, leaving us very close to finishing implementing this feature as well. Overall, learning to use the controllers, modules and AngularJS
directives was probably the hardest part of this project and took me several days. I had significant trouble figuring out how my js files and HTML link
together, what is the scope parameter, how can I call different functions within separate files. I first approached this by trying to create the functions
within googlemaps.init.js, but eventually figured out that this was the wrong way to do it. Some of my efforts and attempts are reflected in an email
conversation with Heads Benedict and Natalie, who kindly offered advice and helped me better understand what I was supposed to do.

Overall, I came close to spending around the same amount of time on the project as I did on all the PSETs combined. I received very little help within
office hours and very limited advice from friends in CS. In addition to Natalie and Benedict, I owe thanks to Kareem, Stelios and Barkley, who helped me
find the right resources and set me on the right path.

Here are my sources:
https://www.w3schools.com/icons/icons_reference.asp
https://www.w3schools.com/icons/default.asp
https://ionicframework.com/docs/api/components/img/Img/
http://docs.usecreator.com/docs/zip-export-an-ionic-project
https://www.wikihow.com/Insert-Spaces-in-HTML https://www.w3schools.com/w3css/w3css_progressbar.asp
https://www.w3schools.com/howto/howto_js_progressbar.asp
https://blog.revillweb.com/angularjs-tutorial-learn-angularjs-in-30-minutes-35b5eae52dc2
https://thinkster.io/a-better-way-to-learn-angularjs
https://github.com/mapsplugin/cordova-plugin-googlemaps
https://www.joshmorony.com/integrating-google-maps-with-an-ionic-application/
https://ionicframework.com/docs/components/#toast
https://github.com/ionic-team/ionic/blob/efd54750bf44b622a20078be02a2335aabc6dcec/src/components/toggle/toggle-gesture.ts
https://codepen.io/ionic/pen/tfAzj
https://stackoverflow.com/questions/35276752/implementing-a-toggle-in-ionic-using-angularjs
https://forum.ionicframework.com/t/adding-an-angular-directive-in-ionic/1552/4
https://devdactic.com/simple-login-example-with-ionic-and-angularjs/
https://www.joshmorony.com/integrating-google-maps-with-an-ionic-application/
https://docs.usecreator.com/docs/directives
https://docs.usecreator.com/docs/working-with-form-data
https://scotch.io/tutorials/creating-a-single-page-todo-app-with-node-and-angular
https://docs.usecreator.com/docs/slider
https://github.com/mapsplugin/cordova-plugin-googlemaps
https://developers.google.com/maps/documentation/javascript/adding-a-google-map
https://ionicframework.com/docs/components/#overview
https://stackoverflow.com/questions/29398806/angular-google-maps-custom-marker-icon
https://github.com/mapsplugin/cordova-plugin-googlemaps/issues/1389
https://stackoverflow.com/questions/43883343/add-custom-marker-with-store-logo-in-ionic-using-google-map
https://github.com/mapsplugin/cordova-plugin-googlemaps-doc/blob/master/v2.0.0/class/Marker/setIcon/README.md
https://cordova.apache.org/docs/en/latest/guide/appdev/hooks/
https://stackoverflow.com/questions/29398806/angular-google-maps-custom-marker-icon
https://www.w3schools.com/js/js_loop_for.asp
https://ionicframework.com/docs/components/#toggle
https://stackoverflow.com/questions/26962266/ui-gmap-markers-showing-only-one-marker
https://github.com/angular-ui/angular-google-maps
http://jsfiddle.net/nigeljvm/duabubeo/9/
https://github.com/angular-ui/angular-google-maps/blob/master/example/assets/scripts/controllers/issue-74-markers-events.js
https://docs.angularjs.org/guide/controller
https://ionicframework.com/docs/native/google-maps/
https://github.com/ionic-team/ionic/blob/efd54750bf44b622a20078be02a2335aabc6dcec/src/components/toggle/toggle-gesture.ts
https://ionicframework.com/docs/components/#alert-checkbox
hide-back-button="false"

