#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <stdint.h>


int main (int argc, char *argv[])
{
    //open the file
    FILE *card = fopen(argv[1], "r");

    //If  program is not executed with exactly one command-line argument. I GET THE ERROR: "EXPECTED EXIT CODE 0, NOT 1", the problem probably lies here, but I couldn't identify it
    if (argc != 2)
    {
        fprintf(stderr, "Usage: type in one command line argument\n");
        return 1;
    }

    //If the forensic image cannot be opened for reading

    if (card == NULL)
    {
        fclose (card);
        fprintf (stderr, "cannot be opened for reading\n");
        return 2;
    }


    typedef uint8_t BYTE;
    BYTE buffer[512];
    // introduce counter to follow how many jpeg files we found and named so far
    int jpegcounter = 0;
    FILE *output = NULL;
    char filename[8];



    //repeat until end of card
    while (fread(buffer, 512, 1, card))
    {
        // look for a start of the jpeg
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {


            // if it's before the first jpeg
            if (jpegcounter == 0)
            {
                //name the jpeg by what the counter value is
                sprintf (filename, "%03i.jpg", jpegcounter);
                //open the file and write into it
                output = fopen(filename, "w");
                fwrite (buffer, 512, 1, output);
            }

            // if it's after the first jpeg file, we have to close the previous one before beginning
            else
            {
                fclose (output);
                sprintf (filename, "%03i.jpg", jpegcounter);
                output = fopen(filename, "w");
                fwrite (buffer, 512, 1, output);
            }
        //increase the count
        jpegcounter++;

        }
        else
        {
            // if we haven't yet opened anything, we don't write
            // if we opened something, we keep writing
            if (jpegcounter >= 1)
            {
                fwrite (buffer, 512, 1, output);
            }
        }


    }
    //close any remaining files
    fclose (output);
    fclose (card);
    return 0;
}