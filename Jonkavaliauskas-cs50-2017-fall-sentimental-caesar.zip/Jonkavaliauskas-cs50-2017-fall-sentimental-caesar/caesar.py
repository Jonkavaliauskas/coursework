import sys
from cs50 import get_string

# Ensure proper usage
if len(sys.argv) != 2:
    print("Improper usage")
    exit(1)

# Initialize
key = int(sys.argv[1]) % 26
c = 0
# Ensure key is non-negative
if key < 0:
    print("Key must be a non-negative integer")
    exit(1)

# Prompt user for plaintext
plaintext = get_string("plaintext: ")

# Encrypt plaintext
print("ciphertext: ", end="")
for i in range(len(plaintext)):
    # Handle uppercase characters
    if plaintext[i].isupper():
        c = ((ord(plaintext[i]) - 65 + key) % 26) + 65
        print(chr(c), end="")
    # Handle lowercase characters
    elif plaintext[i].islower():
        c = ((ord(plaintext[i]) - 97 + key) % 26) + 97
        print(chr(c), end="")
    # Handle other characters
    else:
        print(plaintext[i], end="")
print()
exit(0)
