from cs50 import get_int


def main():
    # set limits for the pyramid height

    # prompt until the right input is given
    while True:
        height = get_int("Height: ")
        if height >= 0 and height <= 23:
            break

    # Calculate pyramid's width
    width = height + 1

    # run this until we reach the desired height
    # Iterate over pyramid's rows
    for i in range(height):
        # Iterate over pyramid's columns
        for j in range(width):
            # Print space
            if j < width - 2 - i:
                print(" ", end="")

            # Print hash
            else:
                print("#", end="")
        # print newline
        print()


if __name__ == "__main__":
    main()
