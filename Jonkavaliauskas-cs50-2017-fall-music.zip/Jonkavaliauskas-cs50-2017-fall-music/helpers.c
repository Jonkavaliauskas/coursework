// Helper functions for music

#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include "helpers.h"
#include <math.h>



// Converts a fraction formatted as X/Y to eighths
int duration(string fraction)
{
    // turn into an number
    int a = fraction[0] - '0';
    int b = fraction[2] - '0';
    int duration = (a * 8) / b;
    return duration;
}

// Calculates frequency (in Hz) of a note
int frequency(string note)
{
    //distinguishing whether it includes flat or sharp or neither, so XY or XYZ
    int n = strlen(note);

    int semitones = 0;
    int accidental = 0;
    int octave = 0;
    if (n == 3)
    {
        // once again, turning it into a number
        octave = note[2] - '0';
        //if flat or sharp
        if (note[1] == 'b')
            accidental = -1;
        else if (note[1] == '#')
            accidental = 1;
    }
    else if (n == 2)
    {
        octave = note[1] - '0';
    }


    //counting letters in front of A (B) and behind it (all the rest) in a given octave
    if (note[0] == 'A')
    {
        semitones = 0;
    }
    else if (note[0] == 'B')
    {
        semitones = 2;
    }
    else if (note[0] == 'C')
    {
        semitones = 9;
    }
    else if (note[0] == 'D')
    {
        semitones = 7;
    }
    else if (note[0] == 'E')
    {
        semitones = 5;
    }
    else if (note[0] == 'F')
    {
        semitones = 4;
    }
    else if (note[0] == 'G')
    {
        semitones = 2;
    }

    int frequency;
    double freq = 440.0;
    // whether flat or sharp, changes the value by:
    if (accidental == 1)
    {
        freq = (freq * pow(2.0, (1.0/12.0)));
    }
    else if (accidental == -1)
    {
        freq = (freq / pow(2.0, (1.0/12.0)));
    }
    //which octave, changes the value by:
    if (octave - 4 >= 0)
    {
        freq = (freq * pow(2.0, (octave-4.0)));
    }
    else
    {
        freq = (freq / pow(2.0, (0.0 - (octave-4.0))));
    }
    // only go up if it's above A, which is just for B, so divide for the rest
    if(note[0] == 'B')
        frequency = lround(freq*pow(2.0,(semitones/12.0)));
    else
        frequency = lround(freq/pow(2.0,(semitones/12.0)));

    return frequency;


}

// Determines whether a string represents a rest
bool is_rest(string s)
{
    //manual: "If user inputs only a line ending, returns "", not NULL.""
    if (strcmp(s, "") == 0)
        return true;
    else
    {
        return false;
    }
}
// received help during office hours, used CS50 Reference, received help from the Kasumyan brothers