from nltk.tokenize import sent_tokenize


def lines(a, b):
    """Return lines in both a and b"""

    # TODO
    # splitting into lines
    x = a.splitlines()
    y = b.splitlines()
    # converting into sets as they're easier to compare, also sets remove duplicates
    z = set(x)
    w = set(y)
    # comparing sets
    g = z & w
    # converting the result back into a list
    e = list(g)
    return e


def sentences(a, b):
    """Return sentences in both a and b"""

    # TODO

    x = sent_tokenize(a)
    y = sent_tokenize(b)
    # converting into sets as they're easier to compare, also sets remove duplicates
    z = set(x)
    w = set(y)
    # comparing sets
    g = z & w
    # converting the result back into a list
    e = list(g)
    return e


def substrings(a, b, n):
    """Return substrings of length n in both a and b"""

    # TODO
    x = set()
    y = set()

    for i in range(len(a) - n + 1):
        temp = a[i:i + n]
        x.add(temp)
    for j in range(len(b) - n + 1):
        temp = b[j:j + n]
        y.add(temp)

    # comparing sets
    g = x & y
    # converting the result back into a list
    e = list(g)
    return e
