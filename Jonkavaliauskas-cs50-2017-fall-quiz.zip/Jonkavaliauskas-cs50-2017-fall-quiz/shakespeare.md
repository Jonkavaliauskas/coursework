# To be or not to be

## ~~That is the question~~ These are the questions

4.1. population_size = 1000, generates a 1000 objects, defined in line 5 as to how many iterations the for loop in line 10 should do

4.2. initializes score to zero, then with a for loop it iterates through the genes, if the ith gene in the dna matches the ith gene in the target,
it increments score by 1. self.fitness is the proportion of matching genes between dna and target.

4.3. used to test out
target = "to be or not to be"
def update_fitness(genes):
    score = 0
    for i in range(len(genes)):
        if genes[i] == target[i]:
            score += 1
    return float(score)/len(target)
print(update_fitness("KoMQ%25\"zHnGt1whXY"))

The answer is: 0.05555555555555555

4.4. Using edit distance we can see how dissimilar are the two strings by looking at the min. number of operations it would take to transform one into another. E.g. Because only the letter "o" matches the required position and therefore has a mutation cost of 0, the cost in the previous example would be 17. To get the same number we would do (length - cost)/length me.

4.5. To get random variations in the children and the population. If there was no mutation, there would be a risk of getting stuck in an infitine loop with mixing the same genes without getting the necessary genes to match the target DNA. The higher the fitness in line 28, the higher the probability that the DNA will reproduce (line 30).

## Debrief

a. https://en.wikipedia.org/wiki/Edit_distance, class and lecture notes

b. 90 minutes
