# Comparing Students

## Questions

1.1. It represents the comparison function which returns a positive integer (if the first argument is greater than the second), a negative integer (if the first argument is less than the second) and zero (if they're equal). "The function must not modify the objects passed to it and must return consistent results when called for the same objects, regardless of their positions in the array." ... "Function pointed to by comp is used for object comparison."

1.2. Here we typecast (convert from one data type to another) the pointers from void to int to be able to read from the array they're pointing to and compare the values against each other.

1.3. See `students.c`.

1.4. See `students.py`.

1.5. See `students.js`.

## Debrief

a. https://stackoverflow.com/questions/27211552/convert-const-void-pointer-to-int-pointer; https://www.le.ac.uk/users/rjm1/cotter/page_19.htm; https://docs.python.org/3/tutorial/controlflow.html#lambda-expressions, lecture and class notes

b. 60 minutes
