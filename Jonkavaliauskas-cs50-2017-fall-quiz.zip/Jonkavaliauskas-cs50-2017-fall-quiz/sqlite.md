# SQLite Music

## Questions

2.1. Because it's referring to a row in another table in the database, in this case - "Artist".

2.2. Because artists have multiple albums and we could not associate them with all of them, as this would mean creating new rows for the same artist to have room for varying album ids, requiring us to assign different artist ids to the same artists, while the artist id is a primary key and needs to be unique. Leads to poor organization also. Not sure if this makes sense, but the bottom line is that artist-album is a one-to-many relationship.

2.3. Easier and faster to sort by, index and perform operations on when organizing and manipulating the database.

2.4. SELECT SUM(Total) FROM Invoice WHERE year(InvoiceDate) = 2010

2.5. SELECT TrackId FROM Invoice JOIN InvoiceLine JOIN Track ON Invoice.CustomerId = InvoiceLine.TackId = Track.Name WHERE Invoice.CustomerId = 50... I thought that here we could use a JOIN function, but I'm not sure. ALTERNATIVELY SELECT t.Name From Track t WHERE (InvoiceLine.InvoiceId = Invoice.InvoiceId AND Invoice.CustomerId = 50 AND t.TrackId = InvoiceLine.TrackId)

2.6. Assign each composer an integer value, order the data based on those integers, providing a separate reference table - this woud be better, because it's easier to manipulate and compare integers than strings. ALTERNATIVELY Create a table for composer, creating a many-to-many relationship between composerid and trackid, for which we need the junction table.

## Debrief

a. https://www.w3schools.com/sql/sql_join.asp; https://docs.cs50.net/2017/fall/notes/10/lecture10.html, https://stackoverflow.com/questions/7296846/how-to-implement-one-to-one-one-to-many-and-many-to-many-relationships-while-de, class and lecture notes

b. 60 minutes
