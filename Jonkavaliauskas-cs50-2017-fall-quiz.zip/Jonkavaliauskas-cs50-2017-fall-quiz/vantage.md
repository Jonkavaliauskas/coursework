# Vantage Points

## Questions

5.1. CSV can be parsed incrementally, so if the data being imported is too large, you can read only parts of it, not overloading the computer.

5.2. JSON is easier to read (has more features for structuring the data in a hierarchical-relational way).

5.3. https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=NFLX&interval=1min&apikey=NAJXWIA8D6VN6A3K&datatype=csv

5.4. All the prices are given as strings, which would make it difficult (you would need to convert first) to manipulate the data. It would perhaps be better to have the prices already converted into number type.

## Debrief

a. https://www.reddit.com/r/golang/comments/46leew/csv_vs_json_which_is_better_to_read_data_from/; https://spacetelescope.github.io/understanding-json-schema/reference/numeric.html

b. 20 minutes
