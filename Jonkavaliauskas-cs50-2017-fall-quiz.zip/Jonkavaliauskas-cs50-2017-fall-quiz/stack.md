# Stack is Back

## Questions

3.1. __init__is a special construtctor/initializer method and is called when one creates a new instance of a class. You can pass variables into __init__ as well.

3.2. See `parser.py`.

3.3. handle_starttag is called when a new tag is encountered while parsing the HTML string.

3.4. handle_endtag is called when a tag is found with a backslash in front of it(endtag).

3.5. See `parser.py`.

## Debrief

a. http://pymbook.readthedocs.io/en/latest/classes.html; http://interactivepython.org/runestone/static/pythonds/BasicDS/ImplementingaStackinPython.html; https://www.thoughtco.com/html-singleton-tags-3468620, class and lecture notes

b. 90 minutes
