# Questions

## What's `stdint.h`?

is a header file in the C standard library introduced in the C99 standard library section 7.18 to allow programmers to write more portable code by providing a set of typedefs that specify exact-width integer types, together with the defined minimum and maximum allowable values for each type, using macros (https://en.wikibooks.org/wiki/C_Programming/stdint.h).

## What's the point of using `uint8_t`, `uint32_t`, `int32_t`, and `uint16_t` in a program?

Specifies the width of the data. E.g. uint8_t suggests that the integer is 8 bits wide

## How many bytes is a `BYTE`, a `DWORD`, a `LONG`, and a `WORD`, respectively?

BYTE = 1 byte; DWORD = 4 bytes; LONG = 4 bytes; WORD = 2 bytes

## What (in ASCII, decimal, or hexadecimal) must the first two bytes of any BMP file be? Leading bytes used to identify file formats (with high probability) are generally called "magic numbers."

The first two bytes identify bfType

## What's the difference between `bfSize` and `biSize`?

biSizeImage > The size, in bytes, of the image. bfSize > The size, in bytes, of the bitmap file. (what is the difference between image & bitmap file ?) biSizeImage is the whole image size, bfSize is the same, but you have to add the size of the 2 header files. (https://stackoverflow.com/questions/25713117/what-is-the-difference-between-bisizeimage-bisize-and-bfsize)

## What does it mean if `biHeight` is negative?

If biHeight is positive, the bitmap is a bottom-up DIB and its origin is the lower-left corner. If biHeight is negative, the bitmap is a top-down DIB and its origin is the upper-left corner. (http://freeimage.sourceforge.net/fnet/html/B4C5405A.htm)

## What field in `BITMAPINFOHEADER` specifies the BMP's color depth (i.e., bits per pixel)?

biBitCount

## Why might `fopen` return `NULL` in lines 24 and 32 of `copy.c`?

The file could not be opened

## Why is the third argument to `fread` always `1` in our code?

As that's the NUMBER of times we go over everything

## What value does line 65 of `copy.c` assign to `padding` if `bi.biWidth` is `3`?

TODO

## What does `fseek` do?

You use fseek when you want to change the offset of the file pointer fp (from CS50 Reference)

## What is `SEEK_CUR`?

The whence argument specifies how the offset should be interpreted, in the same way as for the fseek function, and it must be one of the symbolic constants SEEK_SET , SEEK_CUR , or SEEK_END . SEEK_SET. Specifies that offset is a count of characters from the beginning of the file. (https://www.gnu.org/s/libc/manual/html_node/File-Position-Primitive.html)

//used mostly google for reference and help answering the questions