from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # display stocks
    stocks = db.execute("SELECT symbol, SUM(shares) FROM portfolio WHERE id = :id GROUP BY symbol", id = session["user_id"])

    prices = []
    totalvalues = []

    for stock in stocks:

        symbol = str(stock["symbol"])
        info = lookup(symbol)
        stock['shares'] = stock['SUM(shares)']
        stock['totalvalue'] = info['price']*stock['SUM(shares)']
        stock['price'] = info['price']
        stock['name'] = info['name']


    # display cash
    cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])
    # render the template
    return render_template("index.html", stocks = stocks, cash = cash)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # check whether a symbol is submitted, if not, render an apology
        if not request.form.get("symbol"):
            return apology("must provide a valid symbol")

        # get a number of shares and check whether it's a positive integer
        shares = int(request.form.get("shares"))
        if shares <= 0:
            return apology("the number of shares must be a positive integer value")

        # lookup the stock
        stock = lookup(request.form.get("symbol"))
        name = stock['name']
        price = stock['price']
        symbol = stock['symbol']


        # check the amount of cash a user has
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])
        cash = cash[0]["cash"]
        # check whether the cash the user has is enough for executing the transaction
        if shares*price > cash:
        # if not enough, return an apology and DO NOTHING
            return apology("not enough cash to execute the transaction")

        # otherwise, record the transaction and update the portfolio
        else:
            portfolio = db.execute("INSERT INTO portfolio (symbol, shares, price, id) VALUES(:symbol, :shares, :price, :id)", symbol=symbol, shares=shares, id = session["user_id"])
            # and record the transaction in history
            db.execute("INSERT INTO history (symbol, shares, price, id) VALUES(:symbol, :shares, :price, :id)", symbol=symbol, shares=shares, price=price, id = session["user_id"])
            # and update the cash remaining to the user
            remainingcash = cash - (shares*price)
            db.execute("UPDATE users SET cash = :remainingcash WHERE id = :id", remainingcash = remainingcash, id = session["user_id"])
        return redirect("index.html")

    else:
        return render_template("buy.html")




@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    h = db.execute("SELECT symbol, shares, price, date_time FROM history WHERE id = :id", id = session["user_id"])

    return render_template("history.html", h=h)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    # if user used POST:
    if request.method == "POST":

        # check whether a symbol is submitted, if not, render an apology
        if not request.form.get("symbol"):
            return apology("must provide a valid symbol", 403)

        # lookup the symbol
        share = lookup(request.form.get("symbol"))
        name = share['name']
        price = share['price']
        symbol = share['symbol']

        # if symbol is invalid and not found
        if share == None:
            return apology("must provide a valid symbol", 403)
        else:
            return render_template("quoted.html", name=name, symbol=symbol, price=price)
    else:
        return render_template("quote.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        if not request.form.get("username"):
            return apology("must provide username", 403)
        if not request.form.get("password"):
            return apology("must provide password", 403)
        if not request.form.get("confirmpassword"):
            return apology("must confirm password", 403)
        if request.form.get("password") != request.form.get("confirmpassword"):
            return("passwords do not match", 403)
        # hash password
        hashed = generate_password_hash(request.form.get("password"))
        # enter the new user into the database
        rows = db.execute("INSERT INTO users (username, hash) VALUES(:username, :hash)", username=request.form.get("username"), hash=hashed)
        # check whether the user doesn't already exist. if so, render and apology
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))
        if rows == request.form.get("username"):
            return apology("username already exists", 403)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        # Redirect user to home page
        return redirect("/")

    else:
        return render_template("register.html")

@app.route("/change", methods=["GET", "POST"])
def change():
    """Change Password"""
    if request.method == "POST":
        if not request.form.get("username"):
            return apology("must provide username", 403)
        if not request.form.get("password"):
            return apology("must provide old password", 403)
        if not request.form.get("newpassword"):
            return apology("must provide new password", 403)
        if not request.form.get("confirmnewpassword"):
            return apology("must confirm new password", 403)
        if request.form.get("newpassword") != request.form.get("confirmnewpassword"):
            return("new passwords do not match", 403)
        # hash new password
        hashednew = generate_password_hash(request.form.get("newpassword"))

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))
        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)
        # insert the users info into the database
        rows = db.execute("INSERT INTO users (username, hash) VALUES(:username, :hash)", username=request.form.get("username"), hash=hashednew)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        # Redirect user to home page
        return redirect("/")

    else:
        return render_template("change.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    if request.method == "POST":
       # check whether a symbol is submitted, if not, render an apology
        if not request.form.get("symbol"):
            return apology("must provide a valid symbol")

        # get a number of shares and check whether it's a positive integer
        sshares = int(request.form.get("shares"))
        if sshares <= 0:
            return apology("the number of shares must be a positive integer value")
        sshares = -1 * sshares

        # lookup the stock
        stock = lookup(request.form.get("symbol"))
        name = stock['name']
        price = stock['price']
        symbol = stock['symbol']

        # check the amount of cash a user has
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])
        cash = cash[0]["cash"]
        # check the amount of shares the user has
        portfolio = db.execute("SELECT shares FROM portfolio WHERE id = :id", id=session["user_id"])
        shares = portfolio[0]["Shares"]
        # check whether the shares the user has is enough for executing the transaction
        if shares < sshares:
        # if not enough shares, return an apology and DO NOTHING
            return apology("not enough shares to execute the transaction")

        # otherwise, record the transaction and update the portfolio
        else:
            portfolio = db.execute("INSERT INTO portfolio (symbol, shares, id) VALUES(:symbol, :shares, :id)", symbol=symbol, shares=shares, id=session["user_id"])
            # and record the transaction in history
            db.execute("INSERT INTO history (symbol, shares, price, id) VALUES(:symbol, :shares, :price, :id)", symbol=symbol, shares=-shares, price=price, id=session["user_id"])
            # and update the cash remaining to the user
            remainingcash = cash + (sshares * price)
            db.execute("UPDATE users SET cash = :remainingcash WHERE id = :id", remainingcash = remainingcash, id = session["user_id"])
        return redirect("index.html")
    else:
        return render_template("sell.html")


def errorhandler(e):
    """Handle error"""
    return apology(e.name, e.code)


# listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)

# used https://www.w3schools.com/html/tryit.asp?filename=tryhtml_table and staff solution